loader.define(function(require, exports, module) {
	var pageview = {};

	var $noLogin = $("#noLogin"),
		$hasLogin = $("#hasLogin");
	// 绑定事件
	bind();

	// 事件类定义
	function bind() {
		if (userobj.cstid == null) {
			$noLogin.show();
			$hasLogin.hide();
		} else {
			$noLogin.hide();
			$hasLogin.show();
		}
	};
	pageview.initLogin = function() {
		bind();
	}

	module.exports = pageview;

})