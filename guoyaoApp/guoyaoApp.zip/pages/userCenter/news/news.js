loader.define(function(require, exports, module) {
    bui.ajax({
        url: "json/news.json",
        data: {}, //接口请求的参数

        // 可选参数
        method: "GET",
        timeout: 20000
    }).done(function(result) {
        $(".news-page main .news-page-list").append(template(result.data));

        $(".news-page main .news-page-list .bui-btn").on("click", function() {
            router.load({ url: "pages/userCenter/news/newsDetails.html", param: { id: $(this).data("id") } })
        })
    }).fail(function(result, status) {
        //console.log(status)//"timeout"
    });

    function template(data) {
        var html = '';
        $.each(data, function(i, el) {
            html += '<div class="bui-box bui-btn" data-id="' + el.id + '">';
            html += '    <i class="news-icon ' + el.type + '-icon"></i>';
            html += '    <div class="span1">';
            html += '    <h3 class="item-title">' + el.title + '<span class="time bui-right">' + el.time + '</span></h3>';
            html += '    <p class="item-detail">' + el.content + '<i class="bui-right bui-badges">' + el.count + '</i></p>';
            html += '    </div>';
            html += '</div>';
        });
        return html;
    }
})