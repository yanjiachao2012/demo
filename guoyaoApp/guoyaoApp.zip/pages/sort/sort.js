loader.define(function(require, exports, module) {

	var pageview = {};
	var $sortLeft = $("#sortLeft"),
		$sortRight = $("#sortRight");
	var tempData = []; //临时保存右边数据



	// 事件类定义
	pageview.bind = function() {

		/**
		 *@param 点击左边数据切换
		 **/
		$sortLeft.on("click", '.left-sort', function() {
			var _this = $(this),
				_index = _this.attr('data-index'),
				html = "";
			tempData[_index].forEach(function(item) {
				html += pageview.listRight(item);
			})
			$sortRight.html(html);

			_this.addClass('left-sort-active').siblings('.left-sort').removeClass('left-sort-active');
		});
		/***
		 *@param 跳转链接
		 **/
		$sortRight.on('click', '.sort-item', function() {
			var _this = $(this),
				_word = _this.attr('data-word');
			bui.load({
				url: 'pages/search/search.html',
				param: {
					word: _word
				}

			})
		})
	}
	/***
	 *@param 初始化数据
	 **/
	pageview.initData = function() {
		common.dataAjax({
			url: 'json/sort.json',
			method: 'get'
		}).done(function(res) {

			var htmlObject = pageview.tempData(res.returnValue);
			$sortLeft.html(htmlObject.htmlLeft);
			$sortRight.html(htmlObject.htmlRight);
		}).fail(function(res) {

		})
	}

	/***
	 *@param 模板数据
	 **/
	pageview.tempData = function(data) {
		var data = data || [];
		var htmlLeft = '',
			htmlRight = '';
		data.forEach(function(item, index) {
			if (index == 0) {
				htmlLeft += '<li class="left-sort left-sort-active" data-index=' + index + '>' + item.bigName + '</li>';
				item.sortName.forEach(function(item) {
					htmlRight += pageview.listRight(item);
				})
			} else {
				htmlLeft += '<li class="left-sort" data-index=' + index + '>' + item.bigName + '</li>';
			}
			tempData.push(item.sortName)
		})
		return {
			htmlLeft: htmlLeft,
			htmlRight: htmlRight
		}
	}
	/**
	 *@param 右边数据
	 **/
	pageview.listRight = function(data) {
		var html = '<li class="sort-item" data-word="' + data + '"><span class="sort-name bui-text-hide">' + data + '</span>';
		return html;
	};

	pageview.bind();
	pageview.initData();
})