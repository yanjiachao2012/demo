loader.define(function(require, exports, module) {



    var pageview = {}; // 页面模块
    var $searchHome = $("#searchHome");



    pageview.bind = function() {
        /***
         *跳去搜索页面
         ***/
        $("#searchHome").on('click', function() {
            bui.load({
                url: 'pages/search/search.html'
            })

        })
        $(".toUser").on("click", function() {
            loader.require(["main"], function(res) {
                var pageTab = res.tab;
                pageTab.to(4, "none");
            })
        });
        /**
         *@param 轮播图
         ***/
        uiSlide = bui.slide({
            id: "#homeSlide",
            height: 220,
            zoom: 1,
            autoplay: true
        });

        /**
         *@param 扫码功能的实现
         *@param 
         **/
        $("#scanCode").on("click", function() {
            app.barcode.scan(function(result) {
                bui.alert(result)
            }, function(result) {
                // app.alert(result);
            });
        })
    }

    // 页面初始化
    pageview.init = function() {
        pageview.bind();
    }
    // 初始化
    pageview.init();

    // 输出模块
    module.exports = pageview;
})