loader.define(function(require, exports, module) {
	console.log('1')

	// 绑定事件
	bind();

	// 事件类定义
	function bind() {
		// 绑定页面的所有按钮有href跳转


	}

})