// 默认已经定义了main模块




$("#kk01").click(function (e) {

        bui.load({ url: "pages/test01/test01.html", param: {}});




});
